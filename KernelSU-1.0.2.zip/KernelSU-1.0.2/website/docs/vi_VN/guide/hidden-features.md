# Tính Năng Ẩn

## .ksurc

Theo mặc định, `/system/bin/sh` tải `/system/etc/mkshrc`.

Bạn có thể tạo su tải tệp rc tùy chỉnh bằng cách tạo tệp `/data/adb/ksu/.ksurc`.
